height
runfile('/Users/meza/MyProjects/numerical-mooc/MyCodes/RocketFlight.py', wdir='/Users/meza/MyProjects/numerical-mooc/MyCodes')
vmax
hmax
t_at_hmax
A
2.*np.pi*r**2
u
runfile('/Users/meza/MyProjects/numerical-mooc/MyCodes/RocketFlight.py', wdir='/Users/meza/MyProjects/numerical-mooc/MyCodes')
t_at_vmax
vmax
height
runfile('/Users/meza/MyProjects/numerical-mooc/MyCodes/RocketFlight.py', wdir='/Users/meza/MyProjects/numerical-mooc/MyCodes')
vmax
t_at_vmax
h_at_vmax
runfile('/Users/meza/MyProjects/numerical-mooc/MyCodes/RocketFlight.py', wdir='/Users/meza/MyProjects/numerical-mooc/MyCodes')
t_at_vmax
h_at_vmax
runfile('/Users/meza/MyProjects/numerical-mooc/MyCodes/RocketFlight.py', wdir='/Users/meza/MyProjects/numerical-mooc/MyCodes')
vmax
t_at_vmax
h_at_vmax
hmax
runfile('/Users/meza/MyProjects/numerical-mooc/MyCodes/RocketFlight.py', wdir='/Users/meza/MyProjects/numerical-mooc/MyCodes')
hmax
vmax
h_at_vmax
runfile('/Users/meza/MyProjects/numerical-mooc/MyCodes/RocketFlight.py', wdir='/Users/meza/MyProjects/numerical-mooc/MyCodes')
hmax
vmax
h_at_vmax
t_at_vmax
runfile('/Users/meza/MyProjects/numerical-mooc/MyCodes/RocketFlight.py', wdir='/Users/meza/MyProjects/numerical-mooc/MyCodes')
vmax
t_at_vmax
h_at_vmax
runfile('/Users/meza/MyProjects/numerical-mooc/MyCodes/RocketFlight.py', wdir='/Users/meza/MyProjects/numerical-mooc/MyCodes')
vmax
runfile('/Users/meza/MyProjects/numerical-mooc/MyCodes/RocketFlight.py', wdir='/Users/meza/MyProjects/numerical-mooc/MyCodes')
hmax
t_at_hmax

##---(Fri Sep 19 17:36:12 2014)---
runfile('/Users/meza/MyProjects/numerical-mooc/MyCodes/RocketFlight.py', wdir='/Users/meza/MyProjects/numerical-mooc/MyCodes')
N
rang(N-1)
range(N-1)
runfile('/Users/meza/MyProjects/numerical-mooc/MyCodes/RocketFlight.py', wdir='/Users/meza/MyProjects/numerical-mooc/MyCodes')

##---(Sat Sep 20 14:31:24 2014)---
runfile('/Users/meza/MyProjects/numerical-mooc/MyCodes/RocketFlight.py', wdir='/Users/meza/MyProjects/numerical-mooc/MyCodes')
?numpy.where
h
height[np.where(x>0.)]
height[np.where(heigth>0.)]
height[np.where(height>0.)]
height
tn
t
velocity
vmax
t_at_vmax
h_at_vmax
runfile('/Users/meza/MyProjects/numerical-mooc/MyCodes/RocketFlight.py', wdir='/Users/meza/MyProjects/numerical-mooc/MyCodes')
vmax
t_at_vmax
h_at_vmax
hmax
t_at_hmax
r
2*np.pi*r**2
runfile('/Users/meza/MyProjects/numerical-mooc/MyCodes/RocketFlight.py', wdir='/Users/meza/MyProjects/numerical-mooc/MyCodes')
vmax
t_at_vmax
h_at_vmax
hmax
t_at_hmax
debugfile('/Users/meza/MyProjects/numerical-mooc/MyCodes/RocketFlight.py', wdir='/Users/meza/MyProjects/numerical-mooc/MyCodes')
runfile('/Users/meza/MyProjects/numerical-mooc/MyCodes/RocketFlight.py', wdir='/Users/meza/MyProjects/numerical-mooc/MyCodes')
t
?np.where
mpdot
mpdot = np.linspace(0.0,T,N)
mpdot
?zeros
?np.zeros
t.shape
mpdot = np.zeros(t.shape)
mpdot
mpdot[np.where(t <= 5.0)] = 20
mpdot
runfile('/Users/meza/MyProjects/numerical-mooc/MyCodes/RocketFlight.py', wdir='/Users/meza/MyProjects/numerical-mooc/MyCodes')
height
print height
runfile('/Users/meza/MyProjects/numerical-mooc/MyCodes/RocketFlight.py', wdir='/Users/meza/MyProjects/numerical-mooc/MyCodes')
height
runfile('/Users/meza/MyProjects/numerical-mooc/MyCodes/RocketFlight.py', wdir='/Users/meza/MyProjects/numerical-mooc/MyCodes')
height
runfile('/Users/meza/MyProjects/numerical-mooc/MyCodes/RocketFlight.py', wdir='/Users/meza/MyProjects/numerical-mooc/MyCodes')
quit()

##---(Tue Sep 30 15:50:13 2014)---
linearconv(41)
pwd
pwd
linearconv(41)
?linearconv
?linearconv()
ls
run linearconv.py
?linearconv
linearconv(41)
import numpy
import matplotlib.pyplot as plt
from matplotlib import rcParams
rcParams['font.family'] = 'serif'
rcParams['font.size'] = 16
linearconv(41)
import numpy
linearconv(41)
run linearconv.py
linearconv(41)
import numpy
linearconv(41)
def linearconv(nx):
    """Solve the linear convection equation.

    Solves the equation d_t u + c d_x u = 0 where 
    * the wavespeed c is set to 1
    * the domain is x \in [0, 2]
    * 20 timesteps are taken, with \Delta t = 0.025
    * the initial data is the hat function

    Produces a plot of the results

    Parameters
    ----------

    nx : integer
        number of internal grid points

    Returns
    -------

    None : none
    """
    dx = 2./(nx-1)
    nt = 20    
    dt = .025  
    c = 1

    u = numpy.ones(nx)      
    u[.5/dx : 1/dx+1]=2  

    un = numpy.ones(nx) 

    for n in range(nt): 
        un = u.copy() 
        u[1:] = un[1:] -c*dt/dx*(un[1:] -un[0:-1]) 
        u[0] = 1.0


    plt.plot(numpy.linspace(0,2,nx), u, color='#003366', ls='--', lw=3)
    plt.ylim(0,2.5);
    
linearconv(41)
linearconv(61)
linearconv(71)
linearconv(85)
nx = 41
dx = 2./(nx-1)
nt = 20   
nu = 0.3   #the value of viscosity
sigma = .2 
dt = sigma*dx**2/nu 

x = numpy.linspace(0,2,nx)

u = numpy.ones(nx)      
u[.5/dx : 1/dx+1]=2  

un = numpy.ones(nx)

nx
dx
for n in range(nt):  
    un = u.copy() 
    u[1:-1] = un[1:-1] + nu*dt/dx**2*(un[2:] -2*un[1:-1] +un[0:-2]) 

plt.plot(numpy.linspace(0,2,nx), u, color='#003366', ls='--', lw=3)
plt.ylim(0,2.5);

from JSAnimation.IPython_display import display_animation